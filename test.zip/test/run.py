import os 
main = "upload.cmd"
r_v = os.system(main) 
print (r_v )
